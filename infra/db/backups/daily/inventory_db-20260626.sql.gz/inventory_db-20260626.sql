--
-- PostgreSQL database dump
--

\restrict wbrxPyEHv9hAS1tqY1UnzyxEERaGUOwiKZ6oNDR6SeRyNB5CvVYHRhJ7xbok27y

-- Dumped from database version 15.18
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: timescaledb; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS timescaledb WITH SCHEMA public;


--
-- Name: EXTENSION timescaledb; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION timescaledb IS 'Enables scalable inserts and complex queries for time-series data (Community Edition)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: barcodes; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.barcodes (
    id uuid NOT NULL,
    variant_id uuid,
    value text NOT NULL,
    symbology text NOT NULL,
    source text NOT NULL,
    is_primary boolean DEFAULT false,
    assigned_at timestamp with time zone NOT NULL
);


ALTER TABLE public.barcodes OWNER TO inventory_user;

--
-- Name: external_mappings; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.external_mappings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    integration_id uuid,
    entity_type text NOT NULL,
    internal_id text NOT NULL,
    external_id text NOT NULL,
    external_secondary_id text
);


ALTER TABLE public.external_mappings OWNER TO inventory_user;

--
-- Name: integration_connections; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.integration_connections (
    id uuid NOT NULL,
    tenant_id text NOT NULL,
    platform text NOT NULL,
    store_domain text NOT NULL,
    access_token text NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.integration_connections OWNER TO inventory_user;

--
-- Name: inventory_cost_layers; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.inventory_cost_layers (
    id uuid NOT NULL,
    variant_id uuid,
    initial_quantity integer NOT NULL,
    consumed_quantity integer DEFAULT 0 NOT NULL,
    unit_cost_cents integer NOT NULL,
    received_at timestamp with time zone NOT NULL,
    serial_number text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.inventory_cost_layers OWNER TO inventory_user;

--
-- Name: ledger_entries; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.ledger_entries (
    id uuid NOT NULL,
    tenant_id text NOT NULL,
    location_id text NOT NULL,
    variant_id uuid,
    quantity integer NOT NULL,
    reason text NOT NULL,
    actor_id text NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    reference_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ledger_entries OWNER TO inventory_user;

--
-- Name: product_variants; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.product_variants (
    id uuid NOT NULL,
    product_id uuid,
    sku text NOT NULL,
    tracking_mode text DEFAULT 'quantity'::text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.product_variants OWNER TO inventory_user;

--
-- Name: products; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.products (
    id uuid NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.products OWNER TO inventory_user;

--
-- Name: serialized_item_history; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.serialized_item_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    item_id uuid,
    from_status text NOT NULL,
    to_status text NOT NULL,
    reason text,
    actor_id text NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    reference_id text
);


ALTER TABLE public.serialized_item_history OWNER TO inventory_user;

--
-- Name: serialized_items; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.serialized_items (
    id uuid NOT NULL,
    variant_id uuid,
    serial_number text NOT NULL,
    tenant_id text NOT NULL,
    location_id text NOT NULL,
    status text NOT NULL
);


ALTER TABLE public.serialized_items OWNER TO inventory_user;

--
-- Name: variant_attributes; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.variant_attributes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    variant_id uuid,
    name text NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.variant_attributes OWNER TO inventory_user;

--
-- Data for Name: hypertable; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.hypertable (id, schema_name, table_name, associated_schema_name, associated_table_prefix, num_dimensions, chunk_sizing_func_schema, chunk_sizing_func_name, chunk_target_size, compression_state, compressed_hypertable_id, status) FROM stdin;
1	public	ledger_entries	_timescaledb_internal	_hyper_1	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
\.


--
-- Data for Name: bgw_job; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.bgw_job (id, application_name, schedule_interval, max_runtime, max_retries, retry_period, proc_schema, proc_name, owner, scheduled, fixed_schedule, initial_start, hypertable_id, config, check_schema, check_name, timezone) FROM stdin;
\.


--
-- Data for Name: chunk; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.chunk (id, hypertable_id, schema_name, table_name, compressed_chunk_id, status, osm_chunk, creation_time) FROM stdin;
\.


--
-- Data for Name: chunk_column_stats; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.chunk_column_stats (id, hypertable_id, chunk_id, column_name, range_start, range_end, valid) FROM stdin;
\.


--
-- Data for Name: compression_chunk_size; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.compression_chunk_size (chunk_id, compressed_chunk_id, uncompressed_heap_size, uncompressed_toast_size, uncompressed_index_size, compressed_heap_size, compressed_toast_size, compressed_index_size, numrows_pre_compression, numrows_post_compression, numrows_frozen_immediately) FROM stdin;
\.


--
-- Data for Name: compression_settings; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.compression_settings (relid, compress_relid, segmentby, orderby, orderby_desc, orderby_nullsfirst, index) FROM stdin;
\.


--
-- Data for Name: continuous_agg; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.continuous_agg (mat_hypertable_id, raw_hypertable_id, parent_mat_hypertable_id, user_view_schema, user_view_name, partial_view_schema, partial_view_name, direct_view_schema, direct_view_name, materialized_only, schema_change_timestamp) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_bucket_function; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.continuous_aggs_bucket_function (mat_hypertable_id, bucket_func, bucket_width, bucket_origin, bucket_offset, bucket_timezone, bucket_fixed_width) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_hypertable_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.continuous_aggs_hypertable_invalidation_log (hypertable_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_invalidation_threshold; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.continuous_aggs_invalidation_threshold (hypertable_id, watermark) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_jobs_refresh_ranges; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.continuous_aggs_jobs_refresh_ranges (materialization_id, start_range, end_range, pid, job_id, created_at) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_materialization_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.continuous_aggs_materialization_invalidation_log (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_materialization_ranges; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.continuous_aggs_materialization_ranges (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_watermark; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.continuous_aggs_watermark (mat_hypertable_id, watermark) FROM stdin;
\.


--
-- Data for Name: dimension; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.dimension (id, hypertable_id, column_name, column_type, aligned, num_slices, partitioning_func_schema, partitioning_func, interval_length, compress_interval_length, integer_now_func_schema, integer_now_func) FROM stdin;
1	1	occurred_at	timestamp with time zone	t	\N	\N	\N	604800000000	\N	\N	\N
\.


--
-- Data for Name: dimension_slice; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.dimension_slice (id, chunk_id, dimension_id, range_start, range_end) FROM stdin;
\.


--
-- Data for Name: metadata; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.metadata (key, value, include_in_telemetry) FROM stdin;
install_timestamp	2026-06-25 04:28:40.385034+00	t
timescaledb_version	2.28.1	f
exported_uuid	93e83e6a-10b6-4834-a342-19e033464830	t
\.


--
-- Data for Name: tablespace; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.tablespace (id, hypertable_id, tablespace_name) FROM stdin;
\.


--
-- Data for Name: barcodes; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.barcodes (id, variant_id, value, symbology, source, is_primary, assigned_at) FROM stdin;
\.


--
-- Data for Name: external_mappings; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.external_mappings (id, tenant_id, integration_id, entity_type, internal_id, external_id, external_secondary_id) FROM stdin;
\.


--
-- Data for Name: integration_connections; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.integration_connections (id, tenant_id, platform, store_domain, access_token, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: inventory_cost_layers; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.inventory_cost_layers (id, variant_id, initial_quantity, consumed_quantity, unit_cost_cents, received_at, serial_number, created_at) FROM stdin;
\.


--
-- Data for Name: ledger_entries; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.ledger_entries (id, tenant_id, location_id, variant_id, quantity, reason, actor_id, occurred_at, reference_id, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: product_variants; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.product_variants (id, product_id, sku, tracking_mode, created_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.products (id, name, created_at) FROM stdin;
\.


--
-- Data for Name: serialized_item_history; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.serialized_item_history (id, item_id, from_status, to_status, reason, actor_id, occurred_at, reference_id) FROM stdin;
\.


--
-- Data for Name: serialized_items; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.serialized_items (id, variant_id, serial_number, tenant_id, location_id, status) FROM stdin;
\.


--
-- Data for Name: variant_attributes; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.variant_attributes (id, variant_id, name, value) FROM stdin;
\.


--
-- Name: bgw_job_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: inventory_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.bgw_job_id_seq', 1000, false);


--
-- Name: chunk_column_stats_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: inventory_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_column_stats_id_seq', 1, false);


--
-- Name: chunk_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: inventory_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_id_seq', 1, false);


--
-- Name: dimension_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: inventory_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_id_seq', 1, true);


--
-- Name: dimension_slice_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: inventory_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_slice_id_seq', 1, false);


--
-- Name: hypertable_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: inventory_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.hypertable_id_seq', 1, true);


--
-- Name: barcodes barcodes_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.barcodes
    ADD CONSTRAINT barcodes_pkey PRIMARY KEY (id);


--
-- Name: barcodes barcodes_variant_id_value_key; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.barcodes
    ADD CONSTRAINT barcodes_variant_id_value_key UNIQUE (variant_id, value);


--
-- Name: external_mappings external_mappings_integration_id_entity_type_external_id_key; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.external_mappings
    ADD CONSTRAINT external_mappings_integration_id_entity_type_external_id_key UNIQUE (integration_id, entity_type, external_id);


--
-- Name: external_mappings external_mappings_integration_id_entity_type_internal_id_key; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.external_mappings
    ADD CONSTRAINT external_mappings_integration_id_entity_type_internal_id_key UNIQUE (integration_id, entity_type, internal_id);


--
-- Name: external_mappings external_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.external_mappings
    ADD CONSTRAINT external_mappings_pkey PRIMARY KEY (id);


--
-- Name: integration_connections integration_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.integration_connections
    ADD CONSTRAINT integration_connections_pkey PRIMARY KEY (id);


--
-- Name: inventory_cost_layers inventory_cost_layers_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.inventory_cost_layers
    ADD CONSTRAINT inventory_cost_layers_pkey PRIMARY KEY (id);


--
-- Name: ledger_entries ledger_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_pkey PRIMARY KEY (id, occurred_at);


--
-- Name: product_variants product_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_pkey PRIMARY KEY (id);


--
-- Name: product_variants product_variants_sku_key; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_sku_key UNIQUE (sku);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: serialized_item_history serialized_item_history_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.serialized_item_history
    ADD CONSTRAINT serialized_item_history_pkey PRIMARY KEY (id);


--
-- Name: serialized_items serialized_items_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.serialized_items
    ADD CONSTRAINT serialized_items_pkey PRIMARY KEY (id);


--
-- Name: serialized_items serialized_items_tenant_id_serial_number_key; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.serialized_items
    ADD CONSTRAINT serialized_items_tenant_id_serial_number_key UNIQUE (tenant_id, serial_number);


--
-- Name: variant_attributes variant_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.variant_attributes
    ADD CONSTRAINT variant_attributes_pkey PRIMARY KEY (id);


--
-- Name: variant_attributes variant_attributes_variant_id_name_key; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.variant_attributes
    ADD CONSTRAINT variant_attributes_variant_id_name_key UNIQUE (variant_id, name);


--
-- Name: idx_ledger_variant_location; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE INDEX idx_ledger_variant_location ON public.ledger_entries USING btree (variant_id, location_id);


--
-- Name: ledger_entries_occurred_at_idx; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE INDEX ledger_entries_occurred_at_idx ON public.ledger_entries USING btree (occurred_at DESC);


--
-- Name: barcodes barcodes_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.barcodes
    ADD CONSTRAINT barcodes_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON DELETE CASCADE;


--
-- Name: external_mappings external_mappings_integration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.external_mappings
    ADD CONSTRAINT external_mappings_integration_id_fkey FOREIGN KEY (integration_id) REFERENCES public.integration_connections(id) ON DELETE CASCADE;


--
-- Name: inventory_cost_layers inventory_cost_layers_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.inventory_cost_layers
    ADD CONSTRAINT inventory_cost_layers_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id);


--
-- Name: ledger_entries ledger_entries_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id);


--
-- Name: product_variants product_variants_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: serialized_item_history serialized_item_history_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.serialized_item_history
    ADD CONSTRAINT serialized_item_history_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.serialized_items(id) ON DELETE CASCADE;


--
-- Name: serialized_items serialized_items_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.serialized_items
    ADD CONSTRAINT serialized_items_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id);


--
-- Name: variant_attributes variant_attributes_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.variant_attributes
    ADD CONSTRAINT variant_attributes_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict wbrxPyEHv9hAS1tqY1UnzyxEERaGUOwiKZ6oNDR6SeRyNB5CvVYHRhJ7xbok27y

