--
-- PostgreSQL database dump
--

\restrict z7yEiyqc4Ax8NoXbezHOgDKFofCc3bFhJytMPcFo4kGADNG64gGY8E4juF7vzaV

-- Dumped from database version 15.18
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: timescaledb; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS timescaledb WITH SCHEMA public;


--
-- Name: EXTENSION timescaledb; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION timescaledb IS 'Enables scalable inserts and complex queries for time-series data (Community Edition)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ledger_entries; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.ledger_entries (
    id uuid NOT NULL,
    tenant_id text NOT NULL,
    location_id text NOT NULL,
    variant_id uuid NOT NULL,
    quantity integer NOT NULL,
    reason text NOT NULL,
    actor_id text NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    reference_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.ledger_entries OWNER TO inventory_user;

--
-- Name: _direct_view_2; Type: VIEW; Schema: _timescaledb_internal; Owner: inventory_user
--

CREATE VIEW _timescaledb_internal._direct_view_2 AS
 SELECT public.time_bucket('1 day'::interval, ledger_entries.occurred_at) AS bucket,
    ledger_entries.tenant_id,
    ledger_entries.variant_id,
    COALESCE(sum(
        CASE
            WHEN (ledger_entries.quantity < 0) THEN abs(ledger_entries.quantity)
            ELSE 0
        END), (0)::bigint) AS units_dispatched,
    COALESCE(sum(
        CASE
            WHEN (ledger_entries.quantity > 0) THEN ledger_entries.quantity
            ELSE 0
        END), (0)::bigint) AS units_received,
    count(*) AS transaction_count
   FROM public.ledger_entries
  GROUP BY (public.time_bucket('1 day'::interval, ledger_entries.occurred_at)), ledger_entries.tenant_id, ledger_entries.variant_id;


ALTER TABLE _timescaledb_internal._direct_view_2 OWNER TO inventory_user;

--
-- Name: _materialized_hypertable_2; Type: TABLE; Schema: _timescaledb_internal; Owner: inventory_user
--

CREATE TABLE _timescaledb_internal._materialized_hypertable_2 (
    bucket timestamp with time zone NOT NULL,
    tenant_id text,
    variant_id uuid,
    units_dispatched bigint,
    units_received bigint,
    transaction_count bigint
);


ALTER TABLE _timescaledb_internal._materialized_hypertable_2 OWNER TO inventory_user;

--
-- Name: _partial_view_2; Type: VIEW; Schema: _timescaledb_internal; Owner: inventory_user
--

CREATE VIEW _timescaledb_internal._partial_view_2 AS
 SELECT public.time_bucket('1 day'::interval, ledger_entries.occurred_at) AS bucket,
    ledger_entries.tenant_id,
    ledger_entries.variant_id,
    COALESCE(sum(
        CASE
            WHEN (ledger_entries.quantity < 0) THEN abs(ledger_entries.quantity)
            ELSE 0
        END), (0)::bigint) AS units_dispatched,
    COALESCE(sum(
        CASE
            WHEN (ledger_entries.quantity > 0) THEN ledger_entries.quantity
            ELSE 0
        END), (0)::bigint) AS units_received,
    count(*) AS transaction_count
   FROM public.ledger_entries
  GROUP BY (public.time_bucket('1 day'::interval, ledger_entries.occurred_at)), ledger_entries.tenant_id, ledger_entries.variant_id;


ALTER TABLE _timescaledb_internal._partial_view_2 OWNER TO inventory_user;

--
-- Name: ComplianceLedgerModel; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public."ComplianceLedgerModel" (
    id text NOT NULL,
    "sequenceNumber" integer NOT NULL,
    "tenantId" text NOT NULL,
    "eventType" text NOT NULL,
    payload text NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "previousHash" text NOT NULL,
    hash text NOT NULL,
    signature text NOT NULL
);


ALTER TABLE public."ComplianceLedgerModel" OWNER TO inventory_user;

--
-- Name: api_tokens; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.api_tokens (
    id text NOT NULL,
    user_id text NOT NULL,
    tenant_id text NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.api_tokens OWNER TO inventory_user;

--
-- Name: audit_discrepancies; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.audit_discrepancies (
    id text NOT NULL,
    tenant_id text NOT NULL,
    type text NOT NULL,
    reference_id text NOT NULL,
    external_ref_id text,
    description text NOT NULL,
    status text DEFAULT 'OPEN'::text NOT NULL,
    occurred_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    resolved_at timestamp(3) without time zone,
    resolution_notes text
);


ALTER TABLE public.audit_discrepancies OWNER TO inventory_user;

--
-- Name: barcodes; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.barcodes (
    id uuid NOT NULL,
    variant_id uuid NOT NULL,
    value text NOT NULL,
    symbology text NOT NULL,
    source text NOT NULL,
    is_primary boolean DEFAULT false,
    assigned_at timestamp with time zone NOT NULL
);


ALTER TABLE public.barcodes OWNER TO inventory_user;

--
-- Name: conversion_rules; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.conversion_rules (
    id uuid NOT NULL,
    product_uom_sku text NOT NULL,
    unit_name text NOT NULL,
    unit_abbreviation text NOT NULL,
    unit_category text NOT NULL,
    factor_to_base double precision NOT NULL,
    label text
);


ALTER TABLE public.conversion_rules OWNER TO inventory_user;

--
-- Name: daily_stock_velocity; Type: VIEW; Schema: public; Owner: inventory_user
--

CREATE VIEW public.daily_stock_velocity AS
 SELECT _materialized_hypertable_2.bucket,
    _materialized_hypertable_2.tenant_id,
    _materialized_hypertable_2.variant_id,
    _materialized_hypertable_2.units_dispatched,
    _materialized_hypertable_2.units_received,
    _materialized_hypertable_2.transaction_count
   FROM _timescaledb_internal._materialized_hypertable_2;


ALTER TABLE public.daily_stock_velocity OWNER TO inventory_user;

--
-- Name: demand_forecasts; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.demand_forecasts (
    id uuid NOT NULL,
    sku text NOT NULL,
    location_id text NOT NULL,
    forecasted_quantity integer NOT NULL,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    confidence_level double precision NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.demand_forecasts OWNER TO inventory_user;

--
-- Name: external_mappings; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.external_mappings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id text NOT NULL,
    integration_id uuid NOT NULL,
    entity_type text NOT NULL,
    internal_id text NOT NULL,
    external_id text NOT NULL,
    external_secondary_id text
);


ALTER TABLE public.external_mappings OWNER TO inventory_user;

--
-- Name: integration_connections; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.integration_connections (
    id uuid NOT NULL,
    tenant_id text NOT NULL,
    platform text NOT NULL,
    store_domain text NOT NULL,
    access_token text NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.integration_connections OWNER TO inventory_user;

--
-- Name: inventory_cost_layers; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.inventory_cost_layers (
    id uuid NOT NULL,
    variant_id uuid NOT NULL,
    initial_quantity integer NOT NULL,
    consumed_quantity integer DEFAULT 0 NOT NULL,
    unit_cost_cents integer NOT NULL,
    received_at timestamp with time zone NOT NULL,
    serial_number text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expiration_date timestamp with time zone,
    lot_number text
);


ALTER TABLE public.inventory_cost_layers OWNER TO inventory_user;

--
-- Name: inventory_items; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.inventory_items (
    id text NOT NULL,
    sku text NOT NULL,
    "locationId" text NOT NULL,
    quantity integer NOT NULL,
    allocated integer DEFAULT 0 NOT NULL,
    in_transit integer DEFAULT 0 NOT NULL,
    version integer NOT NULL
);


ALTER TABLE public.inventory_items OWNER TO inventory_user;

--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.journal_entries (
    id uuid NOT NULL,
    tenant_id text NOT NULL,
    date timestamp with time zone NOT NULL,
    description text NOT NULL,
    method text NOT NULL,
    reference_id text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.journal_entries OWNER TO inventory_user;

--
-- Name: journal_lines; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.journal_lines (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    entry_id uuid NOT NULL,
    account_code text NOT NULL,
    amount_cents integer NOT NULL,
    type text NOT NULL,
    memo text
);


ALTER TABLE public.journal_lines OWNER TO inventory_user;

--
-- Name: kit_components; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.kit_components (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    kit_id uuid NOT NULL,
    variant_id uuid NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.kit_components OWNER TO inventory_user;

--
-- Name: kits; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.kits (
    id uuid NOT NULL,
    sku text NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.kits OWNER TO inventory_user;

--
-- Name: netsuite_journal_mappings; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.netsuite_journal_mappings (
    id uuid NOT NULL,
    journal_entry_id uuid NOT NULL,
    netsuite_journal_id text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.netsuite_journal_mappings OWNER TO inventory_user;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    tenant_id text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    type text DEFAULT 'info'::text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.notifications OWNER TO inventory_user;

--
-- Name: outbox_events; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.outbox_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_type text NOT NULL,
    payload text NOT NULL,
    status text DEFAULT 'Pending'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    processed_at timestamp with time zone,
    next_attempt_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.outbox_events OWNER TO inventory_user;

--
-- Name: product_uom_configurations; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.product_uom_configurations (
    sku text NOT NULL,
    base_unit_name text NOT NULL,
    base_unit_abbreviation text NOT NULL,
    base_unit_category text NOT NULL,
    purchase_unit_name text,
    purchase_unit_abbreviation text,
    purchase_unit_category text,
    sale_unit_name text,
    sale_unit_abbreviation text,
    sale_unit_category text
);


ALTER TABLE public.product_uom_configurations OWNER TO inventory_user;

--
-- Name: product_variants; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.product_variants (
    id uuid NOT NULL,
    product_id uuid NOT NULL,
    sku text NOT NULL,
    tracking_mode text DEFAULT 'quantity'::text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    costing_method text DEFAULT 'fifo'::text NOT NULL,
    volume_cubic_meters double precision,
    weight_grams integer
);


ALTER TABLE public.product_variants OWNER TO inventory_user;

--
-- Name: products; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.products (
    id uuid NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.products OWNER TO inventory_user;

--
-- Name: purchase_order_items; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.purchase_order_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    purchase_order_id uuid NOT NULL,
    variant_id uuid NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.purchase_order_items OWNER TO inventory_user;

--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.purchase_orders (
    id uuid NOT NULL,
    tenant_id text NOT NULL,
    supplier_id text NOT NULL,
    destination_location_id text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.purchase_orders OWNER TO inventory_user;

--
-- Name: quarantine_items; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.quarantine_items (
    id uuid NOT NULL,
    variant_id uuid NOT NULL,
    quantity integer NOT NULL,
    reason text NOT NULL,
    status text NOT NULL,
    location_id text NOT NULL,
    tenant_id text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    resolved_at timestamp with time zone
);


ALTER TABLE public.quarantine_items OWNER TO inventory_user;

--
-- Name: quickbooks_journal_mappings; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.quickbooks_journal_mappings (
    id uuid NOT NULL,
    journal_entry_id uuid NOT NULL,
    quickbooks_journal_id text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.quickbooks_journal_mappings OWNER TO inventory_user;

--
-- Name: replenishment_rules; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.replenishment_rules (
    id uuid NOT NULL,
    tenant_id text NOT NULL,
    sku text NOT NULL,
    location_id text NOT NULL,
    reorder_point integer NOT NULL,
    reorder_quantity integer NOT NULL,
    safety_stock integer NOT NULL,
    lead_time_days integer NOT NULL,
    replenishment_type text NOT NULL,
    source_location_id text,
    supplier_id text,
    is_active boolean DEFAULT true NOT NULL,
    dynamic_rop_enabled boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.replenishment_rules OWNER TO inventory_user;

--
-- Name: rma_items; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.rma_items (
    id uuid NOT NULL,
    rma_id uuid NOT NULL,
    variant_id uuid NOT NULL,
    quantity integer NOT NULL,
    received_quantity integer DEFAULT 0 NOT NULL,
    unit_cost_cents integer NOT NULL,
    status text NOT NULL,
    disposition text
);


ALTER TABLE public.rma_items OWNER TO inventory_user;

--
-- Name: rmas; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.rmas (
    id uuid NOT NULL,
    rma_number text NOT NULL,
    tenant_id text NOT NULL,
    customer_id text NOT NULL,
    location_id text NOT NULL,
    status text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.rmas OWNER TO inventory_user;

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.role_permissions (
    role_id text NOT NULL,
    permission text NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO inventory_user;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.roles (
    id text NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.roles OWNER TO inventory_user;

--
-- Name: serialized_item_history; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.serialized_item_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    item_id uuid NOT NULL,
    from_status text NOT NULL,
    to_status text NOT NULL,
    reason text,
    actor_id text NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    reference_id text
);


ALTER TABLE public.serialized_item_history OWNER TO inventory_user;

--
-- Name: serialized_items; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.serialized_items (
    id uuid NOT NULL,
    variant_id uuid NOT NULL,
    serial_number text NOT NULL,
    tenant_id text NOT NULL,
    location_id text NOT NULL,
    status text NOT NULL
);


ALTER TABLE public.serialized_items OWNER TO inventory_user;

--
-- Name: shipments; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.shipments (
    id uuid NOT NULL,
    sku text NOT NULL,
    quantity integer NOT NULL,
    destination_address text NOT NULL,
    carrier text NOT NULL,
    tracking_number text,
    label_url text,
    shipping_rate_cents integer NOT NULL,
    status text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.shipments OWNER TO inventory_user;

--
-- Name: stock_onboarding_items; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.stock_onboarding_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    onboarding_id uuid NOT NULL,
    variant_id uuid NOT NULL,
    quantity integer NOT NULL,
    unit_cost_cents integer NOT NULL
);


ALTER TABLE public.stock_onboarding_items OWNER TO inventory_user;

--
-- Name: stock_onboardings; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.stock_onboardings (
    id uuid NOT NULL,
    tenant_id text NOT NULL,
    location_id text NOT NULL,
    status text NOT NULL,
    as_of_date timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.stock_onboardings OWNER TO inventory_user;

--
-- Name: stock_transfer_items; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.stock_transfer_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    transfer_id uuid NOT NULL,
    variant_id uuid NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.stock_transfer_items OWNER TO inventory_user;

--
-- Name: stock_transfers; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.stock_transfers (
    id uuid NOT NULL,
    tenant_id text NOT NULL,
    source_location_id text NOT NULL,
    destination_location_id text NOT NULL,
    status text NOT NULL,
    reference_id text,
    dispatched_at timestamp with time zone,
    received_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.stock_transfers OWNER TO inventory_user;

--
-- Name: stock_velocity_report; Type: VIEW; Schema: public; Owner: inventory_user
--

CREATE VIEW public.stock_velocity_report AS
 SELECT daily_stock_velocity.bucket,
    daily_stock_velocity.tenant_id,
    daily_stock_velocity.variant_id,
    daily_stock_velocity.units_dispatched,
    daily_stock_velocity.units_received,
    daily_stock_velocity.transaction_count
   FROM public.daily_stock_velocity
  WHERE (daily_stock_velocity.tenant_id = current_setting('app.current_tenant_id'::text, true));


ALTER TABLE public.stock_velocity_report OWNER TO inventory_user;

--
-- Name: tenant_accounting_configs; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.tenant_accounting_configs (
    tenant_id text NOT NULL,
    accounting_method text DEFAULT 'accrual'::text NOT NULL,
    costing_method text DEFAULT 'fifo'::text NOT NULL
);


ALTER TABLE public.tenant_accounting_configs OWNER TO inventory_user;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.tenants (
    id text NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.tenants OWNER TO inventory_user;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.user_roles (
    user_id text NOT NULL,
    role_id text NOT NULL
);


ALTER TABLE public.user_roles OWNER TO inventory_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.users (
    id text NOT NULL,
    tenant_id text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    name text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.users OWNER TO inventory_user;

--
-- Name: variant_attributes; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.variant_attributes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    variant_id uuid NOT NULL,
    name text NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.variant_attributes OWNER TO inventory_user;

--
-- Name: warehouse_locations; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.warehouse_locations (
    id text NOT NULL,
    warehouse_id text NOT NULL,
    zone text NOT NULL,
    aisle text NOT NULL,
    rack text NOT NULL,
    shelf text NOT NULL,
    bin text NOT NULL,
    max_weight_grams integer NOT NULL,
    max_volume_cubic_meters double precision NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    grid_x integer DEFAULT 0 NOT NULL,
    grid_y integer DEFAULT 0 NOT NULL,
    height integer DEFAULT 1 NOT NULL,
    width integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.warehouse_locations OWNER TO inventory_user;

--
-- Name: webhook_deliveries; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.webhook_deliveries (
    id text NOT NULL,
    tenant_id text NOT NULL,
    subscription_id text NOT NULL,
    event_type text NOT NULL,
    payload text NOT NULL,
    status text DEFAULT 'Pending'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    next_attempt_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    processed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.webhook_deliveries OWNER TO inventory_user;

--
-- Name: webhook_events; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.webhook_events (
    id text NOT NULL,
    topic text NOT NULL,
    shop_domain text NOT NULL,
    payload text NOT NULL,
    status text DEFAULT 'Pending'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    occurred_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.webhook_events OWNER TO inventory_user;

--
-- Name: webhook_subscriptions; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.webhook_subscriptions (
    id text NOT NULL,
    tenant_id text NOT NULL,
    target_url text NOT NULL,
    secret text NOT NULL,
    event_types text[],
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.webhook_subscriptions OWNER TO inventory_user;

--
-- Name: xero_journal_mappings; Type: TABLE; Schema: public; Owner: inventory_user
--

CREATE TABLE public.xero_journal_mappings (
    id uuid NOT NULL,
    journal_entry_id uuid NOT NULL,
    xero_journal_id text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.xero_journal_mappings OWNER TO inventory_user;

--
-- Data for Name: hypertable; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.hypertable (id, schema_name, table_name, associated_schema_name, associated_table_prefix, num_dimensions, chunk_sizing_func_schema, chunk_sizing_func_name, chunk_target_size, compression_state, compressed_hypertable_id, status) FROM stdin;
1	public	ledger_entries	_timescaledb_internal	_hyper_1	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
2	_timescaledb_internal	_materialized_hypertable_2	_timescaledb_internal	_hyper_2	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
\.


--
-- Data for Name: bgw_job; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.bgw_job (id, application_name, schedule_interval, max_runtime, max_retries, retry_period, proc_schema, proc_name, owner, scheduled, fixed_schedule, initial_start, hypertable_id, config, check_schema, check_name, timezone) FROM stdin;
1000	Refresh Continuous Aggregate Policy [1000]	01:00:00	00:00:00	-1	01:00:00	_timescaledb_functions	policy_refresh_continuous_aggregate	inventory_user	t	f	\N	2	{"end_offset": "01:00:00", "start_offset": "1 mon", "mat_hypertable_id": 2}	_timescaledb_functions	policy_refresh_continuous_aggregate_check	\N
\.


--
-- Data for Name: chunk; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.chunk (id, hypertable_id, schema_name, table_name, compressed_chunk_id, status, osm_chunk, creation_time) FROM stdin;
\.


--
-- Data for Name: chunk_column_stats; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.chunk_column_stats (id, hypertable_id, chunk_id, column_name, range_start, range_end, valid) FROM stdin;
\.


--
-- Data for Name: compression_chunk_size; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.compression_chunk_size (chunk_id, compressed_chunk_id, uncompressed_heap_size, uncompressed_toast_size, uncompressed_index_size, compressed_heap_size, compressed_toast_size, compressed_index_size, numrows_pre_compression, numrows_post_compression, numrows_frozen_immediately) FROM stdin;
\.


--
-- Data for Name: compression_settings; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.compression_settings (relid, compress_relid, segmentby, orderby, orderby_desc, orderby_nullsfirst, index) FROM stdin;
\.


--
-- Data for Name: continuous_agg; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.continuous_agg (mat_hypertable_id, raw_hypertable_id, parent_mat_hypertable_id, user_view_schema, user_view_name, partial_view_schema, partial_view_name, direct_view_schema, direct_view_name, materialized_only, schema_change_timestamp) FROM stdin;
2	1	\N	public	daily_stock_velocity	_timescaledb_internal	_partial_view_2	_timescaledb_internal	_direct_view_2	t	\N
\.


--
-- Data for Name: continuous_aggs_bucket_function; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.continuous_aggs_bucket_function (mat_hypertable_id, bucket_func, bucket_width, bucket_origin, bucket_offset, bucket_timezone, bucket_fixed_width) FROM stdin;
2	public.time_bucket(interval,timestamp with time zone)	1 day	\N	\N	\N	t
\.


--
-- Data for Name: continuous_aggs_hypertable_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.continuous_aggs_hypertable_invalidation_log (hypertable_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_invalidation_threshold; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.continuous_aggs_invalidation_threshold (hypertable_id, watermark) FROM stdin;
1	1788739200000000
\.


--
-- Data for Name: continuous_aggs_jobs_refresh_ranges; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.continuous_aggs_jobs_refresh_ranges (materialization_id, start_range, end_range, pid, job_id, created_at) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_materialization_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.continuous_aggs_materialization_invalidation_log (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
2	-9223372036854775808	1779926399999999
2	1788739200000000	9223372036854775807
\.


--
-- Data for Name: continuous_aggs_materialization_ranges; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.continuous_aggs_materialization_ranges (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_watermark; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.continuous_aggs_watermark (mat_hypertable_id, watermark) FROM stdin;
2	-210866803200000000
\.


--
-- Data for Name: dimension; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.dimension (id, hypertable_id, column_name, column_type, aligned, num_slices, partitioning_func_schema, partitioning_func, interval_length, compress_interval_length, integer_now_func_schema, integer_now_func) FROM stdin;
1	1	occurred_at	timestamp with time zone	t	\N	\N	\N	604800000000	\N	\N	\N
2	2	bucket	timestamp with time zone	t	\N	\N	\N	6048000000000	\N	\N	\N
\.


--
-- Data for Name: dimension_slice; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.dimension_slice (id, chunk_id, dimension_id, range_start, range_end) FROM stdin;
\.


--
-- Data for Name: metadata; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.metadata (key, value, include_in_telemetry) FROM stdin;
install_timestamp	2026-06-25 04:28:40.385034+00	t
timescaledb_version	2.28.1	f
exported_uuid	93e83e6a-10b6-4834-a342-19e033464830	t
\.


--
-- Data for Name: tablespace; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: inventory_user
--

COPY _timescaledb_catalog.tablespace (id, hypertable_id, tablespace_name) FROM stdin;
\.


--
-- Data for Name: _materialized_hypertable_2; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: inventory_user
--

COPY _timescaledb_internal._materialized_hypertable_2 (bucket, tenant_id, variant_id, units_dispatched, units_received, transaction_count) FROM stdin;
\.


--
-- Data for Name: ComplianceLedgerModel; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public."ComplianceLedgerModel" (id, "sequenceNumber", "tenantId", "eventType", payload, "timestamp", "previousHash", hash, signature) FROM stdin;
\.


--
-- Data for Name: api_tokens; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.api_tokens (id, user_id, tenant_id, token_hash, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: audit_discrepancies; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.audit_discrepancies (id, tenant_id, type, reference_id, external_ref_id, description, status, occurred_at, resolved_at, resolution_notes) FROM stdin;
\.


--
-- Data for Name: barcodes; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.barcodes (id, variant_id, value, symbology, source, is_primary, assigned_at) FROM stdin;
\.


--
-- Data for Name: conversion_rules; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.conversion_rules (id, product_uom_sku, unit_name, unit_abbreviation, unit_category, factor_to_base, label) FROM stdin;
\.


--
-- Data for Name: demand_forecasts; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.demand_forecasts (id, sku, location_id, forecasted_quantity, period_start, period_end, confidence_level, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: external_mappings; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.external_mappings (id, tenant_id, integration_id, entity_type, internal_id, external_id, external_secondary_id) FROM stdin;
\.


--
-- Data for Name: integration_connections; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.integration_connections (id, tenant_id, platform, store_domain, access_token, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: inventory_cost_layers; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.inventory_cost_layers (id, variant_id, initial_quantity, consumed_quantity, unit_cost_cents, received_at, serial_number, created_at, expiration_date, lot_number) FROM stdin;
\.


--
-- Data for Name: inventory_items; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.inventory_items (id, sku, "locationId", quantity, allocated, in_transit, version) FROM stdin;
9963ff4d-280f-4f97-823a-3bd3fc30b3a8	ROUTE-SKU	WH-EAST	5	0	0	2
0ba642ae-bf24-4670-a2c6-61978abc2d8a	ROUTE-SKU	WH-WEST	5	0	0	2
06848ede-4029-4626-9c55-821ec1bb9634	ROUTE-SKU	WH-CENTRAL	10	0	0	2
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.journal_entries (id, tenant_id, date, description, method, reference_id, created_at) FROM stdin;
\.


--
-- Data for Name: journal_lines; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.journal_lines (id, entry_id, account_code, amount_cents, type, memo) FROM stdin;
\.


--
-- Data for Name: kit_components; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.kit_components (id, kit_id, variant_id, quantity) FROM stdin;
\.


--
-- Data for Name: kits; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.kits (id, sku, name, created_at) FROM stdin;
\.


--
-- Data for Name: ledger_entries; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.ledger_entries (id, tenant_id, location_id, variant_id, quantity, reason, actor_id, occurred_at, reference_id, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: netsuite_journal_mappings; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.netsuite_journal_mappings (id, journal_entry_id, netsuite_journal_id, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.notifications (id, tenant_id, title, message, type, is_read, created_at) FROM stdin;
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.outbox_events (id, event_type, payload, status, attempts, last_error, created_at, processed_at, next_attempt_at) FROM stdin;
\.


--
-- Data for Name: product_uom_configurations; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.product_uom_configurations (sku, base_unit_name, base_unit_abbreviation, base_unit_category, purchase_unit_name, purchase_unit_abbreviation, purchase_unit_category, sale_unit_name, sale_unit_abbreviation, sale_unit_category) FROM stdin;
\.


--
-- Data for Name: product_variants; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.product_variants (id, product_id, sku, tracking_mode, created_at, costing_method, volume_cubic_meters, weight_grams) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.products (id, name, created_at) FROM stdin;
\.


--
-- Data for Name: purchase_order_items; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.purchase_order_items (id, purchase_order_id, variant_id, quantity) FROM stdin;
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.purchase_orders (id, tenant_id, supplier_id, destination_location_id, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: quarantine_items; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.quarantine_items (id, variant_id, quantity, reason, status, location_id, tenant_id, created_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: quickbooks_journal_mappings; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.quickbooks_journal_mappings (id, journal_entry_id, quickbooks_journal_id, created_at) FROM stdin;
\.


--
-- Data for Name: replenishment_rules; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.replenishment_rules (id, tenant_id, sku, location_id, reorder_point, reorder_quantity, safety_stock, lead_time_days, replenishment_type, source_location_id, supplier_id, is_active, dynamic_rop_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: rma_items; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.rma_items (id, rma_id, variant_id, quantity, received_quantity, unit_cost_cents, status, disposition) FROM stdin;
\.


--
-- Data for Name: rmas; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.rmas (id, rma_number, tenant_id, customer_id, location_id, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.role_permissions (role_id, permission) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.roles (id, name) FROM stdin;
\.


--
-- Data for Name: serialized_item_history; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.serialized_item_history (id, item_id, from_status, to_status, reason, actor_id, occurred_at, reference_id) FROM stdin;
\.


--
-- Data for Name: serialized_items; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.serialized_items (id, variant_id, serial_number, tenant_id, location_id, status) FROM stdin;
\.


--
-- Data for Name: shipments; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.shipments (id, sku, quantity, destination_address, carrier, tracking_number, label_url, shipping_rate_cents, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stock_onboarding_items; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.stock_onboarding_items (id, onboarding_id, variant_id, quantity, unit_cost_cents) FROM stdin;
\.


--
-- Data for Name: stock_onboardings; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.stock_onboardings (id, tenant_id, location_id, status, as_of_date, created_at) FROM stdin;
\.


--
-- Data for Name: stock_transfer_items; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.stock_transfer_items (id, transfer_id, variant_id, quantity) FROM stdin;
\.


--
-- Data for Name: stock_transfers; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.stock_transfers (id, tenant_id, source_location_id, destination_location_id, status, reference_id, dispatched_at, received_at, created_at) FROM stdin;
\.


--
-- Data for Name: tenant_accounting_configs; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.tenant_accounting_configs (tenant_id, accounting_method, costing_method) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.tenants (id, name, created_at) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.user_roles (user_id, role_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.users (id, tenant_id, email, password_hash, name, active, created_at) FROM stdin;
\.


--
-- Data for Name: variant_attributes; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.variant_attributes (id, variant_id, name, value) FROM stdin;
\.


--
-- Data for Name: warehouse_locations; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.warehouse_locations (id, warehouse_id, zone, aisle, rack, shelf, bin, max_weight_grams, max_volume_cubic_meters, created_at, grid_x, grid_y, height, width) FROM stdin;
\.


--
-- Data for Name: webhook_deliveries; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.webhook_deliveries (id, tenant_id, subscription_id, event_type, payload, status, attempts, last_error, next_attempt_at, processed_at, created_at) FROM stdin;
\.


--
-- Data for Name: webhook_events; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.webhook_events (id, topic, shop_domain, payload, status, attempts, last_error, occurred_at, created_at) FROM stdin;
\.


--
-- Data for Name: webhook_subscriptions; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.webhook_subscriptions (id, tenant_id, target_url, secret, event_types, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: xero_journal_mappings; Type: TABLE DATA; Schema: public; Owner: inventory_user
--

COPY public.xero_journal_mappings (id, journal_entry_id, xero_journal_id, created_at) FROM stdin;
\.


--
-- Name: bgw_job_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: inventory_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.bgw_job_id_seq', 1000, true);


--
-- Name: chunk_column_stats_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: inventory_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_column_stats_id_seq', 1, false);


--
-- Name: chunk_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: inventory_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_id_seq', 1, false);


--
-- Name: dimension_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: inventory_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_id_seq', 2, true);


--
-- Name: dimension_slice_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: inventory_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_slice_id_seq', 1, false);


--
-- Name: hypertable_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: inventory_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.hypertable_id_seq', 2, true);


--
-- Name: ComplianceLedgerModel ComplianceLedgerModel_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public."ComplianceLedgerModel"
    ADD CONSTRAINT "ComplianceLedgerModel_pkey" PRIMARY KEY (id);


--
-- Name: api_tokens api_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_pkey PRIMARY KEY (id);


--
-- Name: audit_discrepancies audit_discrepancies_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.audit_discrepancies
    ADD CONSTRAINT audit_discrepancies_pkey PRIMARY KEY (id);


--
-- Name: barcodes barcodes_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.barcodes
    ADD CONSTRAINT barcodes_pkey PRIMARY KEY (id);


--
-- Name: barcodes barcodes_variant_id_value_key; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.barcodes
    ADD CONSTRAINT barcodes_variant_id_value_key UNIQUE (variant_id, value);


--
-- Name: conversion_rules conversion_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.conversion_rules
    ADD CONSTRAINT conversion_rules_pkey PRIMARY KEY (id);


--
-- Name: demand_forecasts demand_forecasts_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.demand_forecasts
    ADD CONSTRAINT demand_forecasts_pkey PRIMARY KEY (id);


--
-- Name: external_mappings external_mappings_integration_id_entity_type_external_id_key; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.external_mappings
    ADD CONSTRAINT external_mappings_integration_id_entity_type_external_id_key UNIQUE (integration_id, entity_type, external_id);


--
-- Name: external_mappings external_mappings_integration_id_entity_type_internal_id_key; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.external_mappings
    ADD CONSTRAINT external_mappings_integration_id_entity_type_internal_id_key UNIQUE (integration_id, entity_type, internal_id);


--
-- Name: external_mappings external_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.external_mappings
    ADD CONSTRAINT external_mappings_pkey PRIMARY KEY (id);


--
-- Name: integration_connections integration_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.integration_connections
    ADD CONSTRAINT integration_connections_pkey PRIMARY KEY (id);


--
-- Name: inventory_cost_layers inventory_cost_layers_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.inventory_cost_layers
    ADD CONSTRAINT inventory_cost_layers_pkey PRIMARY KEY (id);


--
-- Name: inventory_items inventory_items_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: journal_lines journal_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_pkey PRIMARY KEY (id);


--
-- Name: kit_components kit_components_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.kit_components
    ADD CONSTRAINT kit_components_pkey PRIMARY KEY (id);


--
-- Name: kits kits_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.kits
    ADD CONSTRAINT kits_pkey PRIMARY KEY (id);


--
-- Name: ledger_entries ledger_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_pkey PRIMARY KEY (id, occurred_at);


--
-- Name: netsuite_journal_mappings netsuite_journal_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.netsuite_journal_mappings
    ADD CONSTRAINT netsuite_journal_mappings_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: product_uom_configurations product_uom_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.product_uom_configurations
    ADD CONSTRAINT product_uom_configurations_pkey PRIMARY KEY (sku);


--
-- Name: product_variants product_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_pkey PRIMARY KEY (id);


--
-- Name: product_variants product_variants_sku_key; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_sku_key UNIQUE (sku);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_items purchase_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: quarantine_items quarantine_items_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.quarantine_items
    ADD CONSTRAINT quarantine_items_pkey PRIMARY KEY (id);


--
-- Name: quickbooks_journal_mappings quickbooks_journal_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.quickbooks_journal_mappings
    ADD CONSTRAINT quickbooks_journal_mappings_pkey PRIMARY KEY (id);


--
-- Name: replenishment_rules replenishment_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.replenishment_rules
    ADD CONSTRAINT replenishment_rules_pkey PRIMARY KEY (id);


--
-- Name: rma_items rma_items_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.rma_items
    ADD CONSTRAINT rma_items_pkey PRIMARY KEY (id);


--
-- Name: rmas rmas_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.rmas
    ADD CONSTRAINT rmas_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: serialized_item_history serialized_item_history_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.serialized_item_history
    ADD CONSTRAINT serialized_item_history_pkey PRIMARY KEY (id);


--
-- Name: serialized_items serialized_items_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.serialized_items
    ADD CONSTRAINT serialized_items_pkey PRIMARY KEY (id);


--
-- Name: serialized_items serialized_items_tenant_id_serial_number_key; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.serialized_items
    ADD CONSTRAINT serialized_items_tenant_id_serial_number_key UNIQUE (tenant_id, serial_number);


--
-- Name: shipments shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_pkey PRIMARY KEY (id);


--
-- Name: stock_onboarding_items stock_onboarding_items_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.stock_onboarding_items
    ADD CONSTRAINT stock_onboarding_items_pkey PRIMARY KEY (id);


--
-- Name: stock_onboardings stock_onboardings_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.stock_onboardings
    ADD CONSTRAINT stock_onboardings_pkey PRIMARY KEY (id);


--
-- Name: stock_transfer_items stock_transfer_items_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.stock_transfer_items
    ADD CONSTRAINT stock_transfer_items_pkey PRIMARY KEY (id);


--
-- Name: stock_transfers stock_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_pkey PRIMARY KEY (id);


--
-- Name: tenant_accounting_configs tenant_accounting_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.tenant_accounting_configs
    ADD CONSTRAINT tenant_accounting_configs_pkey PRIMARY KEY (tenant_id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: variant_attributes variant_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.variant_attributes
    ADD CONSTRAINT variant_attributes_pkey PRIMARY KEY (id);


--
-- Name: variant_attributes variant_attributes_variant_id_name_key; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.variant_attributes
    ADD CONSTRAINT variant_attributes_variant_id_name_key UNIQUE (variant_id, name);


--
-- Name: warehouse_locations warehouse_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.warehouse_locations
    ADD CONSTRAINT warehouse_locations_pkey PRIMARY KEY (id);


--
-- Name: webhook_deliveries webhook_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.webhook_deliveries
    ADD CONSTRAINT webhook_deliveries_pkey PRIMARY KEY (id);


--
-- Name: webhook_events webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_pkey PRIMARY KEY (id);


--
-- Name: webhook_subscriptions webhook_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.webhook_subscriptions
    ADD CONSTRAINT webhook_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: xero_journal_mappings xero_journal_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.xero_journal_mappings
    ADD CONSTRAINT xero_journal_mappings_pkey PRIMARY KEY (id);


--
-- Name: _materialized_hypertable_2_bucket_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: inventory_user
--

CREATE INDEX _materialized_hypertable_2_bucket_idx ON _timescaledb_internal._materialized_hypertable_2 USING btree (bucket DESC);


--
-- Name: _materialized_hypertable_2_tenant_id_bucket_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: inventory_user
--

CREATE INDEX _materialized_hypertable_2_tenant_id_bucket_idx ON _timescaledb_internal._materialized_hypertable_2 USING btree (tenant_id, bucket DESC);


--
-- Name: _materialized_hypertable_2_variant_id_bucket_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: inventory_user
--

CREATE INDEX _materialized_hypertable_2_variant_id_bucket_idx ON _timescaledb_internal._materialized_hypertable_2 USING btree (variant_id, bucket DESC);


--
-- Name: ComplianceLedgerModel_sequenceNumber_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX "ComplianceLedgerModel_sequenceNumber_key" ON public."ComplianceLedgerModel" USING btree ("sequenceNumber");


--
-- Name: api_tokens_token_hash_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX api_tokens_token_hash_key ON public.api_tokens USING btree (token_hash);


--
-- Name: demand_forecasts_sku_location_id_period_start_period_end_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX demand_forecasts_sku_location_id_period_start_period_end_key ON public.demand_forecasts USING btree (sku, location_id, period_start, period_end);


--
-- Name: inventory_cost_layers_variant_id_expiration_date_idx; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE INDEX inventory_cost_layers_variant_id_expiration_date_idx ON public.inventory_cost_layers USING btree (variant_id, expiration_date);


--
-- Name: inventory_cost_layers_variant_id_lot_number_idx; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE INDEX inventory_cost_layers_variant_id_lot_number_idx ON public.inventory_cost_layers USING btree (variant_id, lot_number);


--
-- Name: inventory_cost_layers_variant_id_received_at_idx; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE INDEX inventory_cost_layers_variant_id_received_at_idx ON public.inventory_cost_layers USING btree (variant_id, received_at);


--
-- Name: inventory_cost_layers_variant_id_serial_number_idx; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE INDEX inventory_cost_layers_variant_id_serial_number_idx ON public.inventory_cost_layers USING btree (variant_id, serial_number);


--
-- Name: inventory_items_sku_locationId_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX "inventory_items_sku_locationId_key" ON public.inventory_items USING btree (sku, "locationId");


--
-- Name: kit_components_kit_id_variant_id_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX kit_components_kit_id_variant_id_key ON public.kit_components USING btree (kit_id, variant_id);


--
-- Name: kits_sku_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX kits_sku_key ON public.kits USING btree (sku);


--
-- Name: netsuite_journal_mappings_journal_entry_id_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX netsuite_journal_mappings_journal_entry_id_key ON public.netsuite_journal_mappings USING btree (journal_entry_id);


--
-- Name: netsuite_journal_mappings_netsuite_journal_id_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX netsuite_journal_mappings_netsuite_journal_id_key ON public.netsuite_journal_mappings USING btree (netsuite_journal_id);


--
-- Name: purchase_order_items_purchase_order_id_variant_id_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX purchase_order_items_purchase_order_id_variant_id_key ON public.purchase_order_items USING btree (purchase_order_id, variant_id);


--
-- Name: quickbooks_journal_mappings_journal_entry_id_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX quickbooks_journal_mappings_journal_entry_id_key ON public.quickbooks_journal_mappings USING btree (journal_entry_id);


--
-- Name: quickbooks_journal_mappings_quickbooks_journal_id_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX quickbooks_journal_mappings_quickbooks_journal_id_key ON public.quickbooks_journal_mappings USING btree (quickbooks_journal_id);


--
-- Name: replenishment_rules_tenant_id_sku_location_id_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX replenishment_rules_tenant_id_sku_location_id_key ON public.replenishment_rules USING btree (tenant_id, sku, location_id);


--
-- Name: rmas_rma_number_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX rmas_rma_number_key ON public.rmas USING btree (rma_number);


--
-- Name: stock_onboarding_items_onboarding_id_variant_id_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX stock_onboarding_items_onboarding_id_variant_id_key ON public.stock_onboarding_items USING btree (onboarding_id, variant_id);


--
-- Name: stock_transfer_items_transfer_id_variant_id_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX stock_transfer_items_transfer_id_variant_id_key ON public.stock_transfer_items USING btree (transfer_id, variant_id);


--
-- Name: users_tenant_id_email_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX users_tenant_id_email_key ON public.users USING btree (tenant_id, email);


--
-- Name: warehouse_locations_warehouse_id_zone_aisle_rack_shelf_bin_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX warehouse_locations_warehouse_id_zone_aisle_rack_shelf_bin_key ON public.warehouse_locations USING btree (warehouse_id, zone, aisle, rack, shelf, bin);


--
-- Name: xero_journal_mappings_journal_entry_id_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX xero_journal_mappings_journal_entry_id_key ON public.xero_journal_mappings USING btree (journal_entry_id);


--
-- Name: xero_journal_mappings_xero_journal_id_key; Type: INDEX; Schema: public; Owner: inventory_user
--

CREATE UNIQUE INDEX xero_journal_mappings_xero_journal_id_key ON public.xero_journal_mappings USING btree (xero_journal_id);


--
-- Name: api_tokens api_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: barcodes barcodes_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.barcodes
    ADD CONSTRAINT barcodes_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversion_rules conversion_rules_product_uom_sku_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.conversion_rules
    ADD CONSTRAINT conversion_rules_product_uom_sku_fkey FOREIGN KEY (product_uom_sku) REFERENCES public.product_uom_configurations(sku) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: external_mappings external_mappings_integration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.external_mappings
    ADD CONSTRAINT external_mappings_integration_id_fkey FOREIGN KEY (integration_id) REFERENCES public.integration_connections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inventory_cost_layers inventory_cost_layers_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.inventory_cost_layers
    ADD CONSTRAINT inventory_cost_layers_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: journal_lines journal_lines_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES public.journal_entries(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: kit_components kit_components_kit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.kit_components
    ADD CONSTRAINT kit_components_kit_id_fkey FOREIGN KEY (kit_id) REFERENCES public.kits(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ledger_entries ledger_entries_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: product_variants product_variants_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: purchase_order_items purchase_order_items_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rma_items rma_items_rma_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.rma_items
    ADD CONSTRAINT rma_items_rma_id_fkey FOREIGN KEY (rma_id) REFERENCES public.rmas(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: serialized_item_history serialized_item_history_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.serialized_item_history
    ADD CONSTRAINT serialized_item_history_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.serialized_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: serialized_items serialized_items_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.serialized_items
    ADD CONSTRAINT serialized_items_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_onboarding_items stock_onboarding_items_onboarding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.stock_onboarding_items
    ADD CONSTRAINT stock_onboarding_items_onboarding_id_fkey FOREIGN KEY (onboarding_id) REFERENCES public.stock_onboardings(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_transfer_items stock_transfer_items_transfer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.stock_transfer_items
    ADD CONSTRAINT stock_transfer_items_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES public.stock_transfers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: variant_attributes variant_attributes_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory_user
--

ALTER TABLE ONLY public.variant_attributes
    ADD CONSTRAINT variant_attributes_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: api_tokens; Type: ROW SECURITY; Schema: public; Owner: inventory_user
--

ALTER TABLE public.api_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: external_mappings; Type: ROW SECURITY; Schema: public; Owner: inventory_user
--

ALTER TABLE public.external_mappings ENABLE ROW LEVEL SECURITY;

--
-- Name: integration_connections; Type: ROW SECURITY; Schema: public; Owner: inventory_user
--

ALTER TABLE public.integration_connections ENABLE ROW LEVEL SECURITY;

--
-- Name: journal_entries; Type: ROW SECURITY; Schema: public; Owner: inventory_user
--

ALTER TABLE public.journal_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: inventory_user
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: purchase_orders; Type: ROW SECURITY; Schema: public; Owner: inventory_user
--

ALTER TABLE public.purchase_orders ENABLE ROW LEVEL SECURITY;

--
-- Name: quarantine_items; Type: ROW SECURITY; Schema: public; Owner: inventory_user
--

ALTER TABLE public.quarantine_items ENABLE ROW LEVEL SECURITY;

--
-- Name: replenishment_rules; Type: ROW SECURITY; Schema: public; Owner: inventory_user
--

ALTER TABLE public.replenishment_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: rmas; Type: ROW SECURITY; Schema: public; Owner: inventory_user
--

ALTER TABLE public.rmas ENABLE ROW LEVEL SECURITY;

--
-- Name: serialized_items; Type: ROW SECURITY; Schema: public; Owner: inventory_user
--

ALTER TABLE public.serialized_items ENABLE ROW LEVEL SECURITY;

--
-- Name: stock_onboardings; Type: ROW SECURITY; Schema: public; Owner: inventory_user
--

ALTER TABLE public.stock_onboardings ENABLE ROW LEVEL SECURITY;

--
-- Name: stock_transfers; Type: ROW SECURITY; Schema: public; Owner: inventory_user
--

ALTER TABLE public.stock_transfers ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_accounting_configs; Type: ROW SECURITY; Schema: public; Owner: inventory_user
--

ALTER TABLE public.tenant_accounting_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: api_tokens tenant_isolation; Type: POLICY; Schema: public; Owner: inventory_user
--

CREATE POLICY tenant_isolation ON public.api_tokens USING ((tenant_id = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: external_mappings tenant_isolation; Type: POLICY; Schema: public; Owner: inventory_user
--

CREATE POLICY tenant_isolation ON public.external_mappings USING ((tenant_id = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: integration_connections tenant_isolation; Type: POLICY; Schema: public; Owner: inventory_user
--

CREATE POLICY tenant_isolation ON public.integration_connections USING ((tenant_id = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: journal_entries tenant_isolation; Type: POLICY; Schema: public; Owner: inventory_user
--

CREATE POLICY tenant_isolation ON public.journal_entries USING ((tenant_id = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: ledger_entries tenant_isolation; Type: POLICY; Schema: public; Owner: inventory_user
--

CREATE POLICY tenant_isolation ON public.ledger_entries USING ((tenant_id = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: notifications tenant_isolation; Type: POLICY; Schema: public; Owner: inventory_user
--

CREATE POLICY tenant_isolation ON public.notifications USING ((tenant_id = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: purchase_orders tenant_isolation; Type: POLICY; Schema: public; Owner: inventory_user
--

CREATE POLICY tenant_isolation ON public.purchase_orders USING ((tenant_id = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: quarantine_items tenant_isolation; Type: POLICY; Schema: public; Owner: inventory_user
--

CREATE POLICY tenant_isolation ON public.quarantine_items USING ((tenant_id = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: replenishment_rules tenant_isolation; Type: POLICY; Schema: public; Owner: inventory_user
--

CREATE POLICY tenant_isolation ON public.replenishment_rules USING ((tenant_id = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: rmas tenant_isolation; Type: POLICY; Schema: public; Owner: inventory_user
--

CREATE POLICY tenant_isolation ON public.rmas USING ((tenant_id = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: serialized_items tenant_isolation; Type: POLICY; Schema: public; Owner: inventory_user
--

CREATE POLICY tenant_isolation ON public.serialized_items USING ((tenant_id = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: stock_onboardings tenant_isolation; Type: POLICY; Schema: public; Owner: inventory_user
--

CREATE POLICY tenant_isolation ON public.stock_onboardings USING ((tenant_id = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: stock_transfers tenant_isolation; Type: POLICY; Schema: public; Owner: inventory_user
--

CREATE POLICY tenant_isolation ON public.stock_transfers USING ((tenant_id = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: tenant_accounting_configs tenant_isolation; Type: POLICY; Schema: public; Owner: inventory_user
--

CREATE POLICY tenant_isolation ON public.tenant_accounting_configs USING ((tenant_id = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: users user_modify; Type: POLICY; Schema: public; Owner: inventory_user
--

CREATE POLICY user_modify ON public.users USING ((tenant_id = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: users user_select; Type: POLICY; Schema: public; Owner: inventory_user
--

CREATE POLICY user_select ON public.users FOR SELECT USING (true);


--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: inventory_user
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict z7yEiyqc4Ax8NoXbezHOgDKFofCc3bFhJytMPcFo4kGADNG64gGY8E4juF7vzaV

